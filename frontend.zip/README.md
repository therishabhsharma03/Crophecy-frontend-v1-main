
### Start App

Install Dependencies
```
npm install package.json
```

Run Cmd
```
npm start
```
